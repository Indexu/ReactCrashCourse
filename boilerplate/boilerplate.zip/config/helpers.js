/* eslint no-console: 0 */

const path = require('path');
const fs = require('fs');

const appDirectory = fs.realpathSync(process.cwd());
const resolveApp = relativePath => path.resolve(appDirectory, relativePath);

const getPagePaths = () => {
  const pageFileRegex = /.*\.index\.js/;
  const pagesDir = `${resolveApp('src/components/pages')}`;
  const pageFiles = [];

  console.log('Finding page entry points...');

  fs.readdirSync(pagesDir).forEach(pageDirName => {
    const pageDir = path.resolve(pagesDir, pageDirName);

    fs.readdirSync(pageDir).forEach(file => {
      if (pageFileRegex.test(file)) {
        console.log(`\t${pageDirName} - ${file}`);

        pageFiles.push({
          component: pageDirName,
          entryPath: `${pageDir}\\${file}`,
        });
      }
    });
  });

  return pageFiles;
};

const getPageEntryPoints = () => {
  const pagePaths = getPagePaths();

  const entry = {};

  pagePaths.forEach(({ component, entryPath }) => {
    entry[component] = entryPath;
  });

  return entry;
};

module.exports = {
  getPageEntryPoints,
};
