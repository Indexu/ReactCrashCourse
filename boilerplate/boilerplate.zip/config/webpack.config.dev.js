const merge = require('webpack-merge');
const fs = require('fs');
const path = require('path');
const common = require('./webpack.config.common.js');
const paths = require('./paths');

const mode = 'development';

process.env.BABEL_ENV = mode;
process.env.NODE_ENV = mode;

module.exports = (env, argv) => {
  const { https } = argv;

  const httpsConfig = https
    ? {
        https: true,
        pfx: fs.readFileSync(paths.devCert),
        pfxPassphrase: 'Vip123$.',
      }
    : {};

  return merge(common(env, argv), {
    devServer: {
      contentBase: paths.appPublic,
      watchContentBase: true,
      publicPath: '/',
      open: true,
      hot: true,
      overlay: true,
      inline: true,
      port: 3000,
      ...httpsConfig,
    },
    mode,
    devtool: 'eval',
    output: {
      devtoolModuleFilenameTemplate: info => path.resolve(info.absoluteResourcePath).replace(/\\/g, '/'),
    },
    performance: {
      hints: false,
    },
  });
};
