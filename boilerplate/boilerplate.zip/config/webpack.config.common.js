const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
const CleanWebpackPlugin = require('clean-webpack-plugin');
const paths = require('./paths');
const helpers = require('./helpers');

module.exports = (env, { analyze }) => ({
  entry: helpers.getPageEntryPoints(),
  output: {
    publicPath: '/',
    path: paths.appBuild,
    filename: 'static/js/[name].bundle.js',
    chunkFilename: 'static/js/[name].chunk.js',
  },
  optimization: {
    splitChunks: {
      cacheGroups: {
        commons: {
          name: 'common',
          chunks: 'initial',
          minChunks: 2,
        },
      },
    },
  },
  module: {
    strictExportPresence: true,
    rules: [
      { parser: { requireEnsure: false } },
      {
        enforce: 'pre',
        test: /\.(js|jsx)$/,
        exclude: /node_modules/,
        loader: 'eslint-loader',
      },
      {
        test: /\.(js|jsx|mjs)$/,
        exclude: /node_modules/,
        loader: 'babel-loader',
        options: {
          cacheDirectory: true,
          cacheCompression: true,
          compact: true,
          sourceMaps: false,
        },
      },
      {
        exclude: [/\.(js|jsx|mjs)$/, /\.html$/, /\.json$/],
        loader: 'url-loader',
        options: {
          limit: 10000,
        },
      },
    ],
  },
  resolve: {
    extensions: ['.mjs', '.web.js', '.js', '.json', '.web.jsx', '.jsx'],
  },
  plugins: [
    analyze && new BundleAnalyzerPlugin(),
    new CleanWebpackPlugin([`${paths.appBuild}/**/*`], { allowExternal: true }),
  ].filter(Boolean),
});
