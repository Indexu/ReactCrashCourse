const merge = require('webpack-merge');
const TerserPlugin = require('terser-webpack-plugin');
const path = require('path');
const common = require('./webpack.config.common.js');
const paths = require('./paths');

const mode = 'production';

process.env.BABEL_ENV = mode;
process.env.NODE_ENV = mode;

module.exports = (env, argv) =>
  merge(common(env, argv), {
    mode,
    bail: true,
    devtool: false,
    output: {
      pathinfo: false,
      devtoolModuleFilenameTemplate: info => path.relative(paths.appSrc, info.absoluteResourcePath).replace(/\\/g, '/'),
    },
    performance: {
      maxAssetSize: 1000000, // 1Mb,
      maxEntrypointSize: 1000000, // 1Mb
    },
    optimization: {
      minimizer: [
        new TerserPlugin({
          cache: true,
          parallel: true,
          sourceMap: false,
          terserOptions: {
            parse: {
              ecma: 8,
            },
            compress: {
              ecma: 5,
              warnings: false,
              comparisons: false,
              inline: 2,
            },
            mangle: {
              safari10: true,
            },
            output: {
              beautify: false,
              comments: /@preserve|@cc_on|license|copyright/i,
              ascii_only: true,
            },
          },
        }),
      ],
    },
  });
