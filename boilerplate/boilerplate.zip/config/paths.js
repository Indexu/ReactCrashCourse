const path = require('path');
const fs = require('fs');

const appDirectory = fs.realpathSync(process.cwd());
const resolveApp = relativePath => path.resolve(appDirectory, relativePath);

module.exports = {
  appBuild: resolveApp('../Scripts/react'),
  appPublic: resolveApp('public'),
  appSrc: resolveApp('src'),
  devCert: resolveApp('config/ssl/localhost.pfx'),
};
