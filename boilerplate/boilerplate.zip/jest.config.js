module.exports = {
  setupTestFrameworkScriptFile: './config/setupTestFramework.js',
  collectCoverageFrom: ['src/**/*.{js,jsx}', '!**/node_modules/**', '!coverage/**', '!src/**/*.index.js'],
  transformIgnorePatterns: ['/node_modules/(?!styled-icons|react-epic-spinners).+(js|jsx)'],
};
