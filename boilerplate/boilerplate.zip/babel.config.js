module.exports = api => {
  const isProd = api.env('production');
  const isTest = api.env('test');

  api.cache.forever();

  return {
    presets: [['@babel/preset-env', { modules: false }], '@babel/preset-react'],
    plugins: [
      [
        'babel-plugin-styled-components',
        {
          ssr: false,
          displayName: !isProd,
        },
      ],
      '@babel/plugin-syntax-dynamic-import',
      '@babel/plugin-syntax-import-meta',
      '@babel/plugin-transform-runtime',
      '@babel/plugin-proposal-class-properties',
      '@babel/plugin-proposal-json-strings',
      [
        '@babel/plugin-proposal-decorators',
        {
          legacy: true,
        },
      ],
      '@babel/plugin-proposal-function-sent',
      '@babel/plugin-proposal-export-namespace-from',
      '@babel/plugin-proposal-numeric-separator',
      '@babel/plugin-proposal-throw-expressions',
      isTest && '@babel/plugin-transform-modules-commonjs',
    ].filter(Boolean),
  };
};
